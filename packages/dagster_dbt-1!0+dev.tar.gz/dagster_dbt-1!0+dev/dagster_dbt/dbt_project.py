import logging
import os
from collections.abc import Sequence
from pathlib import Path

from dagster._annotations import public
from dagster._record import IHaveNew, record_custom
from dagster._utils import run_with_concurrent_update_guard
from dagster_shared.yaml_utils import safe_load_yaml

from dagster_dbt.errors import (
    DagsterDbtManifestNotFoundError,
    DagsterDbtProfilesDirectoryNotFoundError,
    DagsterDbtProjectNotFoundError,
    DagsterDbtProjectYmlFileNotFoundError,
)

logger = logging.getLogger("dagster-dbt.artifacts")


def using_dagster_dev() -> bool:
    return bool(os.getenv("DAGSTER_IS_DEV_CLI"))


class DbtProjectPreparer:
    """The abstract class of a preparer for a DbtProject representation.

    When implemented, this handler should provide an experience of:
        * The behavior expected during development and at run time, in the `on_load` method.
        * The implementation of the preparation process, in the `prepare` method.
    """

    @public
    def prepare_if_dev(self, project: "DbtProject") -> None:
        """Invoked in the `prepare_if_dev` method of DbtProject,
        when DbtProject needs preparation during development.
        """

    @public
    def prepare(self, project: "DbtProject") -> None:
        """Called explicitly to prepare the manifest for this the project."""

    @public
    def using_dagster_dev(self) -> bool:
        """Returns true if Dagster is running using the `dagster dev` command."""
        return using_dagster_dev()


class DagsterDbtProjectPreparer(DbtProjectPreparer):
    def __init__(
        self,
        prepare_project_cli_args: Sequence[str] | None = None,
    ):
        """The default DbtProjectPreparer, this handler provides an experience of:
            * During development, reload the manifest at run time to pick up any changes.
            * When deploying, expect a manifest that was created at build time to reduce start-up time.

        Args:
            prepare_project_cli_args (Sequence[str]):
                The arguments to pass to the dbt cli to generate a manifest.json.
                Default: ["parse", "--quiet"]
        """
        self._prepare_project_cli_args = prepare_project_cli_args or ["parse", "--quiet"]

    @public
    def prepare_if_dev(self, project: "DbtProject"):
        """Handle the preparation process during development and at run time.

        The preparation process is executed if the condition is met,
        i.e. if the self.using_dagster_dev is true.

        This method returns successfully if a loadable manifest file at the expected path.

        Args:
            project (DbtProject):
                The dbt project to be prepared.
        """
        if self.using_dagster_dev():
            self.prepare(project)
            if not project.manifest_path.exists():
                raise DagsterDbtManifestNotFoundError(
                    f"Did not find manifest.json at expected path {project.manifest_path} "
                    f"after running '{self.prepare.__qualname__}'. Ensure the implementation respects "
                    "all DbtProject properties."
                )

    @public
    def prepare(self, project: "DbtProject") -> None:
        """Execute the preparation process.

        The preparation process:
            * pulls and installs the dependencies of the dbt project,
            * parses the dbt project and created a loadable manifest file.

        Args:
            project (DbtProject):
                The dbt project to be prepared.
        """
        # Always run dbt deps when dependency files exist, not just when
        # packages appear uninstalled. The has_uninstalled_deps check uses a
        # heuristic (dbt_packages dir existence) that can incorrectly skip
        # deps when dependencies have changed but the directory still exists.
        # dbt deps itself is fast when packages are already up-to-date.
        has_deps_files = (
            project.project_dir.joinpath("dependencies.yml").exists()
            or project.project_dir.joinpath("packages.yml").exists()
        )
        if has_deps_files:
            run_with_concurrent_update_guard(
                Path(project.project_dir).joinpath("package-lock.yml"),
                self._prepare_packages,
                project=project,
            )

        run_with_concurrent_update_guard(
            project.manifest_path,
            self._prepare_manifest,
            project=project,
        )

    def _prepare_packages(self, project: "DbtProject") -> None:
        from dagster_dbt.core.resource import DbtCliResource

        (
            DbtCliResource(project_dir=project)
            .cli(["deps", "--quiet"], target_path=project.target_path)
            .wait()
        )

    def _prepare_manifest(self, project: "DbtProject") -> None:
        from dagster_dbt.core.resource import DbtCliResource

        (
            DbtCliResource(project_dir=project)
            .cli(
                self._prepare_project_cli_args,
                target_path=project.target_path,
            )
            .wait()
        )

        # Remove seed entries from partial_parse to force re-parsing at runtime.
        # This ensures seeds get correct root_path based on current project location.
        self._invalidate_seeds_in_partial_parse(project)

    def _invalidate_seeds_in_partial_parse(self, project: "DbtProject") -> None:
        """Force dbt to re-parse seeds by invalidating their partial-parse cache entry.

        Seeds contain root_path which is an absolute path from build time. When state
        is generated in one environment (e.g., CI/CD) and used in another (e.g., deployed
        container), the root_path points to the wrong location and seed loading fails.

        To force a re-parse we overwrite the saved checksum of each seed file entry with
        a sentinel value that can never match the on-disk file. On the next parse, dbt's
        partial-parser sees the checksum mismatch and treats the seed as a normally-changed
        file, re-parsing it through its standard code path and refreshing root_path. Models
        keep their cached data for fast loading.

        We deliberately key off ``parse_file_type == "seed"`` rather than the ``.csv``
        extension: dbt unit-test fixtures are also ``.csv`` files, and removing their file
        entries while leaving the corresponding fixture objects in the saved manifest causes
        dbt to re-add them on the next parse, raising a duplicate-resource compile error.
        See https://github.com/dagster-io/dagster/issues/33471.
        """
        import msgpack

        partial_parse_path = project.project_dir / project.target_path / "partial_parse.msgpack"
        if not partial_parse_path.exists():
            return

        with open(partial_parse_path, "rb") as f:
            data = msgpack.unpack(f, raw=False, strict_map_key=False)

        # Sentinel checksum that cannot match any real file, forcing dbt to re-parse
        # the seed (and only the seed) on the next invocation.
        invalid_checksum = {"name": "sha256", "checksum": "0" * 64}
        for file_entry in data.get("files", {}).values():
            if file_entry.get("parse_file_type") == "seed":
                file_entry["checksum"] = invalid_checksum

        with open(partial_parse_path, "wb") as f:
            msgpack.pack(data, f)


@record_custom
class DbtProject(IHaveNew):
    """Representation of a dbt project and related settings that assist with managing the project preparation.

    Using this helps achieve a setup where the dbt manifest file
    and dbt dependencies are available and up-to-date:
    * during development, pull the dependencies and reload the manifest at run time to pick up any changes.
    * when deployed, expect a manifest that was created at build time to reduce start-up time.

    The cli ``dagster-dbt project prepare-and-package`` can be used as part of the deployment process to
    handle the project preparation.

    This object can be passed directly to :py:class:`~dagster_dbt.DbtCliResource`.

    Args:
        project_dir (Union[str, Path]):
            The directory of the dbt project.
        target_path (Union[str, Path]):
            The path, relative to the project directory, to output artifacts.
            It corresponds to the target path in dbt.
            Default: "target"
        profiles_dir (Union[str, Path]):
            The path to the directory containing your dbt `profiles.yml`.
            By default, the current working directory is used, which is the dbt project directory.
        profile (Optional[str]):
            The profile from your dbt `profiles.yml` to use for execution, if it should be explicitly set.
        target (Optional[str]):
            The target from your dbt `profiles.yml` to use for execution, if it should be explicitly set.
        packaged_project_dir (Optional[Union[str, Path]]):
            A directory that will contain a copy of the dbt project and the manifest.json
            when the artifacts have been built. The prepare method will handle syncing
            the project_path to this directory.
            This is useful when the dbt project needs to be part of the python package data
            like when deploying using PEX.
        state_path (Optional[Union[str, Path]]):
            The path, relative to the project directory, to reference artifacts from another run.

    Examples:
        Creating a DbtProject with by referencing the dbt project directory:

        .. code-block:: python

            from pathlib import Path

            from dagster_dbt import DbtProject

            my_project = DbtProject(project_dir=Path("path/to/dbt_project"))

        Creating a DbtProject that changes target based on environment variables and uses manged state artifacts:

        .. code-block:: python

            import os
            from pathlib import Path
            from dagster_dbt import DbtProject


            def get_env():
                if os.getenv("DAGSTER_CLOUD_IS_BRANCH_DEPLOYMENT", "") == "1":
                    return "BRANCH"
                if os.getenv("DAGSTER_CLOUD_DEPLOYMENT_NAME", "") == "prod":
                    return "PROD"
                return "LOCAL"


            dbt_project = DbtProject(
                project_dir=Path('path/to/dbt_project'),
                state_path="target/managed_state",
                target=get_env(),
            )

    """

    name: str
    project_dir: Path
    target_path: Path
    profiles_dir: Path
    profile: str | None
    target: str | None
    manifest_path: Path
    packaged_project_dir: Path | None
    state_path: Path | None
    has_uninstalled_deps: bool
    preparer: DbtProjectPreparer

    def __new__(
        cls,
        project_dir: Path | str,
        *,
        target_path: Path | str = Path("target"),
        profiles_dir: Path | str | None = None,
        profile: str | None = None,
        target: str | None = None,
        packaged_project_dir: Path | str | None = None,
        state_path: Path | str | None = None,
        prepare_project_cli_args: Sequence[str] | None = None,
    ) -> "DbtProject":
        project_dir = Path(project_dir)
        if not project_dir.exists():
            raise DagsterDbtProjectNotFoundError(f"project_dir {project_dir} does not exist.")

        target_path = Path(target_path)

        packaged_project_dir = Path(packaged_project_dir) if packaged_project_dir else None
        if not using_dagster_dev() and packaged_project_dir and packaged_project_dir.exists():
            project_dir = packaged_project_dir

        # Handling the profiles_dir must be done after the packaged_project_dir is handled
        profiles_dir = Path(profiles_dir) if profiles_dir else project_dir
        if not profiles_dir.exists():
            raise DagsterDbtProfilesDirectoryNotFoundError(
                f"profiles {profiles_dir} does not exist."
            )

        preparer = DagsterDbtProjectPreparer(prepare_project_cli_args=prepare_project_cli_args)

        manifest_path = project_dir.joinpath(target_path, "manifest.json")

        dependencies_path = project_dir.joinpath("dependencies.yml")
        packages_path = project_dir.joinpath("packages.yml")

        dbt_project_yml_path = project_dir.joinpath("dbt_project.yml")
        if not dbt_project_yml_path.exists():
            raise DagsterDbtProjectYmlFileNotFoundError(
                f"Did not find dbt_project.yml at expected path {dbt_project_yml_path}. "
                f"Ensure the specified project directory respects all dbt project requirements."
            )
        with open(project_dir.joinpath("dbt_project.yml"), encoding="utf-8") as file:
            dbt_project_yml = safe_load_yaml(file)
        packages_install_path = project_dir.joinpath(
            dbt_project_yml.get("packages-install-path", "dbt_packages")
        )

        has_uninstalled_deps = (
            dependencies_path.exists() or packages_path.exists()
        ) and not packages_install_path.exists()

        if state_path:
            state_path = Path(state_path)
            if not state_path.is_absolute():
                state_path = project_dir.joinpath(state_path)

        return super().__new__(
            cls,
            name=dbt_project_yml["name"],
            project_dir=project_dir,
            target_path=target_path,
            profiles_dir=profiles_dir,
            profile=profile,
            target=target,
            manifest_path=manifest_path,
            state_path=state_path,
            packaged_project_dir=packaged_project_dir,
            has_uninstalled_deps=has_uninstalled_deps,
            preparer=preparer,
        )

    @public
    def prepare_if_dev(self) -> None:
        """Prepare a dbt project at run time during development, i.e. when `dagster dev` is used.
        This method has no effect outside this development context.

        The preparation process ensures that the dbt manifest file and dbt dependencies are available and up-to-date.
        During development, it pulls the dependencies and reloads the manifest at run time to pick up any changes.

        If this method returns successfully, `self.manifest_path` will point to a loadable manifest file.
        This method causes errors if the manifest file has not been correctly created by the preparation process.

        Examples:
            Preparing a DbtProject during development:

            .. code-block:: python

                from pathlib import Path

                from dagster import Definitions
                from dagster_dbt import DbtProject

                my_project = DbtProject(project_dir=Path("path/to/dbt_project"))
                my_project.prepare_if_dev()

                Definitions(
                    resources={
                        "dbt": DbtCliResource(project_dir=my_project),
                    },
                    ...
                )
        """
        if self.preparer:
            self.preparer.prepare_if_dev(self)
