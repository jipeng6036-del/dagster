import json
from copy import deepcopy

import pytest
import responses
from dagster import (
    AssetKey,
    AssetSelection,
    AutoMaterializePolicy,
    MetadataValue,
    asset,
    define_asset_job,
    file_relative_path,
)
from dagster._config.field_utils import EnvVar
from dagster._core.definitions.assets.graph.asset_graph import AssetGraph
from dagster._core.definitions.partitions.definition import DailyPartitionsDefinition
from dagster._core.test_utils import environ, instance_for_test
from dagster_dbt import (
    DagsterDbtCloudJobInvariantViolationError,
    DbtCloudClientResource,
    load_assets_from_dbt_cloud_job,
)
from dagster_dbt.cloud.asset_defs import DAGSTER_DBT_COMPILE_RUN_ID_ENV_VAR
from dagster_dbt.cloud.resources import DbtCloudClient

from dagster_dbt_tests.cloud.utils import (
    DBT_CLOUD_ACCOUNT_ID,
    DBT_CLOUD_API_TOKEN,
    assert_assets_match_project,
    sample_get_environment_variables,
)

DBT_CLOUD_PROJECT_ID = 12
DBT_CLOUD_JOB_ID = 123
DBT_CLOUD_RUN_ID = 1234
DBT_CLOUD_ENVIRONMENT_ID = 376530

with open(file_relative_path(__file__, "sample_manifest.json"), encoding="utf8") as f:
    MANIFEST_JSON = json.load(f)

with open(file_relative_path(__file__, "sample_run_results.json"), encoding="utf8") as f:
    RUN_RESULTS_JSON = json.load(f)


def _add_dbt_cloud_job_responses(
    dbt_cloud_service: DbtCloudClient,
    dbt_commands: list[str],
    run_results_json: dict | None = None,
    job: dict | None = {},
):
    run_results_json = run_results_json or RUN_RESULTS_JSON

    responses.add(
        method=responses.GET,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/jobs/{DBT_CLOUD_JOB_ID}/",
        json={
            "data": {
                "project_id": DBT_CLOUD_PROJECT_ID,
                "environment_id": DBT_CLOUD_ENVIRONMENT_ID,
                "generate_docs": True,
                "execute_steps": dbt_commands,
                "name": "A dbt Cloud job",
                "id": DBT_CLOUD_JOB_ID,
            }
        },
        status=200,
    )
    responses.get(
        url=f"{dbt_cloud_service.api_v3_base_url}{DBT_CLOUD_ACCOUNT_ID}/projects/{DBT_CLOUD_PROJECT_ID}/environment-variables/job?job_definition_id={DBT_CLOUD_JOB_ID}",
        json={"data": {}},
    )
    responses.add(
        method=responses.POST,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/jobs/{DBT_CLOUD_JOB_ID}/",
        json={"data": {}},
        status=200,
    )
    responses.add(
        method=responses.GET,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/",
        json={"data": [{"id": DBT_CLOUD_RUN_ID}]},
        status=200,
    )
    responses.add(
        method=responses.GET,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{DBT_CLOUD_RUN_ID}/artifacts/manifest.json",
        json=MANIFEST_JSON,
        status=200,
    )
    responses.add(
        method=responses.GET,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{DBT_CLOUD_RUN_ID}/artifacts/run_results.json",
        json=run_results_json,
        status=200,
    )
    responses.add(
        method=responses.POST,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/jobs/{DBT_CLOUD_JOB_ID}/run/",
        json={"data": {"id": DBT_CLOUD_RUN_ID, "href": "/"}},
        status=200,
    )
    responses.add(
        method=responses.GET,
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{DBT_CLOUD_RUN_ID}/",
        json={"data": {"status_humanized": "Success", "job": job, "id": DBT_CLOUD_RUN_ID}},
        status=200,
    )


@responses.activate
@pytest.mark.parametrize("before_dbt_materialization_command", [[], ["dbt test"]])
@pytest.mark.parametrize("dbt_materialization_command", ["dbt run", "dbt build"])
@pytest.mark.parametrize(
    "after_dbt_materialization_command",
    [[], ["dbt run-operation upload_dbt_artifacts --args '{filenames: [manifest, run_results]}'"]],
)
@pytest.mark.parametrize(
    ["dbt_materialization_command_options", "expected_dbt_materialization_command_options"],
    [
        ("-s a:b c:d *x", "--select a:b c:d *x"),
        ("--exclude e:f g:h", "--exclude e:f g:h"),
        ("--selector x:y", "--selector x:y"),
        (
            "-s a:b c:d --exclude e:f g:h --selector x:y",
            "--select a:b c:d --exclude e:f g:h --selector x:y",
        ),
    ],
)
def test_load_assets_from_dbt_cloud_job(
    mocker,
    before_dbt_materialization_command,
    dbt_materialization_command,
    after_dbt_materialization_command,
    dbt_materialization_command_options,
    expected_dbt_materialization_command_options,
    dbt_cloud,
    dbt_cloud_service,
):
    dbt_commands = (
        before_dbt_materialization_command
        + [f"{dbt_materialization_command} {dbt_materialization_command_options}"]
        + after_dbt_materialization_command
    )
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=dbt_commands,
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    mock_run_job_and_poll = mocker.patch(
        "dagster_dbt.cloud.resources.DbtCloudClient.run_job_and_poll",
        wraps=dbt_cloud_cacheable_assets._dbt_cloud.run_job_and_poll,  # noqa: SLF001  # ty: ignore[unresolved-attribute]
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause="Generating software-defined assets for Dagster.",
        steps_override=[f"dbt compile {expected_dbt_materialization_command_options}"],
    )

    assert_assets_match_project(
        dbt_cloud_assets, include_seeds_and_snapshots=False, has_non_argument_deps=True
    )

    mock_run_job_and_poll.reset_mock()

    # Assert that the outputs have the correct metadata
    for output in dbt_cloud_assets[0].op.output_dict.values():
        # Check user-facing metadata
        assert "dbt Cloud Job" in output.metadata
        assert "dbt Cloud Documentation" in output.metadata
        assert output.metadata["dbt Cloud Job"] == MetadataValue.url(
            dbt_cloud_service.build_url_for_job(
                project_id=DBT_CLOUD_PROJECT_ID, job_id=DBT_CLOUD_JOB_ID
            )
        )

        # Check internal tracking metadata
        assert output.metadata["dagster_dbt/cloud_account_id"] == MetadataValue.int(
            DBT_CLOUD_ACCOUNT_ID
        )
        assert output.metadata["dagster_dbt/cloud_project_id"] == MetadataValue.int(
            DBT_CLOUD_PROJECT_ID
        )
        assert output.metadata["dagster_dbt/cloud_environment_id"] == MetadataValue.int(
            DBT_CLOUD_ENVIRONMENT_ID
        )

    materialize_cereal_assets = define_asset_job(
        name="materialize_cereal_assets",
        selection=AssetSelection.assets(*dbt_cloud_assets),
    ).resolve(asset_graph=AssetGraph.from_assets(dbt_cloud_assets))

    with instance_for_test() as instance:
        result = materialize_cereal_assets.execute_in_process(instance=instance)

    assert result.success

    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause=f"Materializing software-defined assets in Dagster run {result.run_id[:8]}",
        steps_override=dbt_commands,
    )


@responses.activate
def test_load_assets_from_dbt_cloud_job_null_job(
    dbt_cloud,
    dbt_cloud_service,
):
    """Regression test for https://github.com/dagster-io/dagster/issues/34317.

    dbt Cloud can return `"job": null` (not `{}`) in the run details payload.
    Materializing assets from such a run must not raise AttributeError.
    """
    dbt_commands = ["dbt run"]
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=dbt_commands,
        job=None,
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    materialize_assets_job = define_asset_job(
        name="materialize_assets_null_job",
        selection=AssetSelection.assets(*dbt_cloud_assets),
    ).resolve(asset_graph=AssetGraph.from_assets(dbt_cloud_assets))

    with instance_for_test() as instance:
        result = materialize_assets_job.execute_in_process(instance=instance)

    assert result.success


@responses.activate
@pytest.mark.parametrize("before_dbt_materialization_command", [[], ["dbt test"]])
@pytest.mark.parametrize("dbt_materialization_command", ["dbt run", "dbt build"])
@pytest.mark.parametrize(
    "after_dbt_materialization_command",
    [[], ["dbt run-operation upload_dbt_artifacts --args '{filenames: [manifest, run_results]}'"]],
)
@pytest.mark.parametrize(
    "dbt_materialization_command_options",
    [
        "-s a:b c:d *x",
        "--exclude e:f g:h",
        "--selector x:y",
        "-s a:b c:d --exclude e:f g:h --selector x:y",
    ],
)
def test_load_assets_from_cached_compile_run(
    mocker,
    before_dbt_materialization_command,
    dbt_materialization_command,
    after_dbt_materialization_command,
    dbt_materialization_command_options,
    dbt_cloud,
    dbt_cloud_service,
):
    environment_variable_id = 1
    cached_compile_run_id = "12345"
    dbt_commands = (
        before_dbt_materialization_command
        + [f"{dbt_materialization_command} {dbt_materialization_command_options}"]
        + after_dbt_materialization_command
    )
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=dbt_commands,
    )
    responses.replace(
        responses.GET,
        url=f"{dbt_cloud_service.api_v3_base_url}{DBT_CLOUD_ACCOUNT_ID}/projects/{DBT_CLOUD_PROJECT_ID}/environment-variables/job?job_definition_id={DBT_CLOUD_JOB_ID}",
        json=sample_get_environment_variables(
            environment_variable_id=environment_variable_id,
            name=DAGSTER_DBT_COMPILE_RUN_ID_ENV_VAR,
            value=cached_compile_run_id,
        ),
    )
    responses.get(
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{cached_compile_run_id}/?include_related=trigger,run_steps",
        json={
            "data": {
                "trigger": {"generate_docs_override": False},
                "run_steps": [{}],
                "status_humanized": "Success",
            }
        },
    )
    responses.get(
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{cached_compile_run_id}/artifacts/manifest.json",
        json=MANIFEST_JSON,
    )
    responses.get(
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{cached_compile_run_id}/artifacts/run_results.json",
        json=RUN_RESULTS_JSON,
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
    )

    mock_run_job_and_poll = mocker.patch(
        "dagster_dbt.cloud.resources.DbtCloudClient.run_job_and_poll",
        wraps=dbt_cloud_cacheable_assets._dbt_cloud.run_job_and_poll,  # noqa: SLF001  # ty: ignore[unresolved-attribute]
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    # Assert that no compile job was run, since we looked into the cache
    mock_run_job_and_poll.assert_not_called()

    assert_assets_match_project(
        dbt_cloud_assets, include_seeds_and_snapshots=False, has_non_argument_deps=True
    )

    mock_run_job_and_poll.reset_mock()

    # Assert that the outputs have the correct metadata
    for output in dbt_cloud_assets[0].op.output_dict.values():
        # Check user-facing metadata
        assert "dbt Cloud Job" in output.metadata
        assert "dbt Cloud Documentation" in output.metadata
        assert output.metadata["dbt Cloud Job"] == MetadataValue.url(
            dbt_cloud_service.build_url_for_job(
                project_id=DBT_CLOUD_PROJECT_ID, job_id=DBT_CLOUD_JOB_ID
            )
        )

        # Check internal tracking metadata
        assert output.metadata["dagster_dbt/cloud_account_id"] == MetadataValue.int(
            DBT_CLOUD_ACCOUNT_ID
        )
        assert output.metadata["dagster_dbt/cloud_project_id"] == MetadataValue.int(
            DBT_CLOUD_PROJECT_ID
        )
        assert output.metadata["dagster_dbt/cloud_environment_id"] == MetadataValue.int(
            DBT_CLOUD_ENVIRONMENT_ID
        )

    materialize_cereal_assets = define_asset_job(
        name="materialize_cereal_assets",
        selection=AssetSelection.assets(*dbt_cloud_assets),
    ).resolve(asset_graph=AssetGraph.from_assets(dbt_cloud_assets))

    with instance_for_test() as instance:
        result = materialize_cereal_assets.execute_in_process(instance=instance)

    assert result.success

    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause=f"Materializing software-defined assets in Dagster run {result.run_id[:8]}",
        steps_override=dbt_commands,
    )


@responses.activate
def test_invalid_cached_compile_run(dbt_cloud, dbt_cloud_service):
    environment_variable_id = 1
    cached_compile_run_id = "12345"

    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
    )
    responses.replace(
        responses.GET,
        url=f"{dbt_cloud_service.api_v3_base_url}{DBT_CLOUD_ACCOUNT_ID}/projects/{DBT_CLOUD_PROJECT_ID}/environment-variables/job?job_definition_id={DBT_CLOUD_JOB_ID}",
        json=sample_get_environment_variables(
            environment_variable_id=environment_variable_id,
            name=DAGSTER_DBT_COMPILE_RUN_ID_ENV_VAR,
            value=cached_compile_run_id,
        ),
    )
    responses.get(
        url=f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{cached_compile_run_id}/?include_related=trigger,run_steps",
        json={
            "data": {
                "trigger": {"generate_docs_override": False},
                "run_steps": [{}],
                "status_humanized": "Running",
                "href": "https://cloud.getdbt.com",
            }
        },
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    with pytest.raises(DagsterDbtCloudJobInvariantViolationError):
        dbt_cloud_cacheable_assets.compute_cacheable_data()


@responses.activate
@pytest.mark.parametrize(
    "invalid_dbt_commands",
    [
        [],
        ["dbt deps"],
        ["dbt deps", "dbt test"],
        [f"dbt build --vars '{json.dumps({'static_variable': 'bad'})}'"],
    ],
    ids=[
        "empty commands",
        "no run/build step",
        "multiple commands, no run/build step",
        "has static variables",
    ],
)
def test_invalid_dbt_cloud_job_commands(dbt_cloud, dbt_cloud_service, invalid_dbt_commands):
    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=invalid_dbt_commands,
    )

    with pytest.raises(DagsterDbtCloudJobInvariantViolationError):
        dbt_cloud_cacheable_assets.compute_cacheable_data()


@responses.activate
def test_empty_assets_dbt_cloud_job(dbt_cloud, dbt_cloud_service):
    empty_run_results_json = deepcopy(RUN_RESULTS_JSON)
    empty_run_results_json["results"] = []
    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
        run_results_json=empty_run_results_json,
    )

    with pytest.raises(DagsterDbtCloudJobInvariantViolationError):
        dbt_cloud_cacheable_assets.compute_cacheable_data()


@responses.activate
def test_custom_groups(dbt_cloud, dbt_cloud_service):
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
        node_info_to_group_fn=lambda node_info: next(iter(node_info["tags"]), None),
    )
    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    assert dbt_cloud_assets[0].group_names_by_key == {
        AssetKey(["cold_schema", "sort_cold_cereals_by_calories"]): "foo",
        AssetKey(["sort_by_calories"]): "foo",
        AssetKey(["sort_hot_cereals_by_calories"]): "bar",
        AssetKey(["subdir_schema", "least_caloric"]): "bar",
    }


@responses.activate
def test_node_info_to_asset_key(dbt_cloud, dbt_cloud_service):
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
        node_info_to_asset_key=lambda node_info: AssetKey(["foo", node_info["name"]]),
    )
    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    assert dbt_cloud_assets[0].group_names_by_key.keys() == {
        AssetKey(["foo", "sort_cold_cereals_by_calories"]),
        AssetKey(["foo", "sort_by_calories"]),
        AssetKey(["foo", "sort_hot_cereals_by_calories"]),
        AssetKey(["foo", "least_caloric"]),
    }


@responses.activate
def test_custom_auto_materialize_policy(dbt_cloud, dbt_cloud_service):
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
        node_info_to_auto_materialize_policy_fn=lambda _: AutoMaterializePolicy.eager(),
    )
    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    assert dbt_cloud_assets[0].auto_materialize_policies_by_key == {
        key: AutoMaterializePolicy.eager() for key in dbt_cloud_assets[0].keys
    }


@responses.activate
def test_partitions(mocker, dbt_cloud, dbt_cloud_service):
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=["dbt build"],
    )

    partition_def = DailyPartitionsDefinition(start_date="2022-01-01")
    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
        partitions_def=partition_def,
        partition_key_to_vars_fn=lambda partition_key: {"run_date": partition_key},
    )

    mock_run_job_and_poll = mocker.patch(
        "dagster_dbt.cloud.resources.DbtCloudClient.run_job_and_poll",
        wraps=dbt_cloud_cacheable_assets._dbt_cloud.run_job_and_poll,  # noqa: SLF001  # ty: ignore[unresolved-attribute]
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause="Generating software-defined assets for Dagster.",
        steps_override=[
            "dbt compile --vars"
            f" '{json.dumps({'run_date': partition_def.get_last_partition_key()})}'"
        ],
    )

    mock_run_job_and_poll.reset_mock()

    materialize_cereal_assets = define_asset_job(
        name="materialize_partitioned_cereal_assets",
        selection=AssetSelection.assets(*dbt_cloud_assets),
    ).resolve(asset_graph=AssetGraph.from_assets(dbt_cloud_assets))

    with instance_for_test() as instance:
        result = materialize_cereal_assets.execute_in_process(
            instance=instance,
            partition_key="2022-02-01",
        )

    assert result.success

    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause=f"Materializing software-defined assets in Dagster run {result.run_id[:8]}",
        steps_override=[f"dbt build --vars '{json.dumps({'run_date': '2022-02-01'})}'"],
    )


@responses.activate
@pytest.mark.parametrize(
    "dbt_materialization_command_subsetting_options",
    ["", "--selector xyz", "--select subdir_schema/least_caloric -s=sort_by_calories"],
    ids=["no selector", "with selector", "with --select args"],
)
@pytest.mark.parametrize(
    "dbt_materialization_command_non_subsetting_options",
    ["", "--target dev"],
    ids=["without non-selection commands", "with non-selection commands"],
)
@pytest.mark.parametrize(
    "asset_selection, expected_dbt_asset_names",
    [
        (
            "*",
            "",  # All dbt assets are chosen, so no selection is made
        ),
        (
            "sort_by_calories+",
            "",  # All dbt assets are chosen, so no selection is made
        ),
        (
            "*hanger2",
            "dagster_dbt_test_project.sort_by_calories,dagster_dbt_test_project.subdir.least_caloric",
        ),
        (
            [
                "cold_schema/sort_cold_cereals_by_calories",
                "subdir_schema/least_caloric",
            ],
            "dagster_dbt_test_project.sort_cold_cereals_by_calories,dagster_dbt_test_project.subdir.least_caloric",
        ),
    ],
)
def test_subsetting(
    mocker,
    dbt_cloud,
    dbt_cloud_service,
    dbt_materialization_command_subsetting_options,
    dbt_materialization_command_non_subsetting_options,
    asset_selection,
    expected_dbt_asset_names,
):
    dbt_materialization_command = "dbt build"
    # Core command should not be changed by dagster
    core_dbt_materialization_command = f"{dbt_materialization_command} {dbt_materialization_command_non_subsetting_options}".strip()
    full_dbt_materialization_command = f"{core_dbt_materialization_command} {dbt_materialization_command_subsetting_options}".strip()

    expected_dbt_asset_names_list = (
        expected_dbt_asset_names.split(",") if expected_dbt_asset_names else []
    )

    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=[full_dbt_materialization_command],
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud,
        job_id=DBT_CLOUD_JOB_ID,
    )

    mock_run_job_and_poll = mocker.patch(
        "dagster_dbt.cloud.resources.DbtCloudClient.run_job_and_poll",
        wraps=dbt_cloud_cacheable_assets._dbt_cloud.run_job_and_poll,  # noqa: SLF001  # ty: ignore[unresolved-attribute]
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    mock_run_job_and_poll.reset_mock()

    @asset(deps=[AssetKey("sort_by_calories")])
    def hanger1():
        return None

    @asset(deps=[AssetKey(["subdir_schema", "least_caloric"])])
    def hanger2():
        return None

    materialize_cereal_assets = define_asset_job(
        name="materialize_cereal_assets",
        selection=asset_selection,
    ).resolve(asset_graph=AssetGraph.from_assets([*dbt_cloud_assets, hanger1, hanger2]))

    if expected_dbt_asset_names_list:
        filtered_results = [
            result
            for result in RUN_RESULTS_JSON["results"]
            if result["unique_id"][len("model.") :] in expected_dbt_asset_names_list
        ]
        run_results_json = {**RUN_RESULTS_JSON, "results": filtered_results}
    else:
        run_results_json = RUN_RESULTS_JSON

    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=[full_dbt_materialization_command],
        run_results_json=run_results_json,
    )
    with instance_for_test() as instance:
        result = materialize_cereal_assets.execute_in_process(instance=instance)

    assert result.success

    dbt_filter_option = (
        f"--select {' '.join(expected_dbt_asset_names_list)}"
        if expected_dbt_asset_names_list
        else ""
    )
    mock_run_job_and_poll.assert_called_once_with(
        job_id=DBT_CLOUD_JOB_ID,
        cause=f"Materializing software-defined assets in Dagster run {result.run_id[:8]}",
        steps_override=[
            (
                f"{core_dbt_materialization_command} {dbt_filter_option}".strip()
                if dbt_filter_option
                else full_dbt_materialization_command
            )
        ],
    )


@responses.activate
def test_load_from_dbt_cloud_with_env_var(dbt_cloud_service) -> None:
    with environ(
        {
            "DBT_CLOUD_API_TOKEN": DBT_CLOUD_API_TOKEN,
            "DBT_CLOUD_ACCOUNT_ID": str(DBT_CLOUD_ACCOUNT_ID),
        }
    ):
        dbt_cloud = DbtCloudClientResource(
            auth_token=EnvVar("DBT_CLOUD_API_TOKEN"), account_id=EnvVar.int("DBT_CLOUD_ACCOUNT_ID")
        )

        _add_dbt_cloud_job_responses(
            dbt_cloud_service=dbt_cloud_service, dbt_commands=["dbt build"]
        )

        dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
            dbt_cloud=dbt_cloud,
            job_id=DBT_CLOUD_JOB_ID,
        )
        dbt_cloud_cacheable_assets.compute_cacheable_data()

        # Ensure the requests were made with the correct auth token, sourced from env
        assert all(
            [
                call.request.headers["Authorization"] == f"Bearer {DBT_CLOUD_API_TOKEN}"
                for call in responses.calls
            ]
        )

        # Implicitly, we check that requests are made with the right account ID, since that is a part of the URLs
        # we set up in _add_dbt_cloud_job_responses


@responses.activate
def test_dbt_cloud_metadata_ids(dbt_cloud, dbt_cloud_service):
    """Test that dbt Cloud asset specs contain the correct ID metadata."""
    dbt_commands = ["dbt run"]
    _add_dbt_cloud_job_responses(
        dbt_cloud_service=dbt_cloud_service,
        dbt_commands=dbt_commands,
    )

    dbt_cloud_cacheable_assets = load_assets_from_dbt_cloud_job(
        dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
    )

    dbt_assets_definition_cacheable_data = dbt_cloud_cacheable_assets.compute_cacheable_data()
    dbt_cloud_assets = dbt_cloud_cacheable_assets.build_definitions(
        dbt_assets_definition_cacheable_data
    )

    # Verify that all outputs have the required ID metadata
    for output in dbt_cloud_assets[0].op.output_dict.values():
        metadata = output.metadata

        assert metadata["dagster_dbt/cloud_account_id"] == MetadataValue.int(DBT_CLOUD_ACCOUNT_ID)
        assert metadata["dagster_dbt/cloud_project_id"] == MetadataValue.int(DBT_CLOUD_PROJECT_ID)
        assert metadata["dagster_dbt/cloud_environment_id"] == MetadataValue.int(
            DBT_CLOUD_ENVIRONMENT_ID
        )


@responses.activate
@pytest.mark.parametrize("generate_docs", [True, False])
@pytest.mark.parametrize("job_state", ["null", "present", "empty"])
@pytest.mark.parametrize("rebuild_from_cache", [True, False])
def test_load_assets_from_dbt_cloud_job_artifact_step(
    dbt_cloud, dbt_cloud_service, generate_docs, job_state, rebuild_from_cache
):
    _add_dbt_cloud_job_responses(dbt_cloud_service, ["dbt run"])
    job_url = f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/jobs/{DBT_CLOUD_JOB_ID}/"
    responses.replace(
        responses.GET,
        job_url,
        json={
            "data": {
                "project_id": DBT_CLOUD_PROJECT_ID,
                "environment_id": DBT_CLOUD_ENVIRONMENT_ID,
                "generate_docs": generate_docs,
                "execute_steps": ["dbt run"],
                "name": "A dbt Cloud job",
                "id": DBT_CLOUD_JOB_ID,
            }
        },
    )
    run_details = {
        "status_humanized": "Success",
        "id": DBT_CLOUD_RUN_ID,
        "run_steps": [{}] * (1 + generate_docs),
        "account_id": DBT_CLOUD_ACCOUNT_ID,
    }
    if job_state != "missing":
        run_details["job"] = (
            None
            if job_state == "null"
            else {"generate_docs": generate_docs}
            if job_state == "present"
            else {}
        )
    responses.replace(
        responses.GET,
        f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}/runs/{DBT_CLOUD_RUN_ID}/",
        json={"data": run_details},
    )
    for artifact, payload in [
        ("manifest.json", MANIFEST_JSON),
        ("run_results.json", RUN_RESULTS_JSON),
    ]:
        artifact_url = (
            f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}"
            f"/runs/{DBT_CLOUD_RUN_ID}/artifacts/{artifact}"
        )
        responses.remove(responses.GET, artifact_url)
        if artifact == "run_results.json":
            responses.add(
                responses.GET,
                artifact_url,
                json=payload,
                match=[responses.matchers.query_param_matcher({})],
            )
        # Compilation always skips its docs step. Preserve the existing empty-job behavior
        # only when choosing the artifacts for the materialization run.
        responses.add(
            responses.GET,
            artifact_url,
            json=payload,
            match=[responses.matchers.query_param_matcher({"step": "1"})],
        )

    cacheable_assets = load_assets_from_dbt_cloud_job(dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID)
    data = cacheable_assets.compute_cacheable_data()
    if rebuild_from_cache:
        cacheable_assets = load_assets_from_dbt_cloud_job(
            dbt_cloud=dbt_cloud, job_id=DBT_CLOUD_JOB_ID
        )
    assets = cacheable_assets.build_definitions(data)
    if job_state == "empty" and generate_docs:
        for artifact, payload in [
            ("manifest.json", MANIFEST_JSON),
            ("run_results.json", RUN_RESULTS_JSON),
        ]:
            artifact_url = (
                f"{dbt_cloud_service.api_v2_base_url}{DBT_CLOUD_ACCOUNT_ID}"
                f"/runs/{DBT_CLOUD_RUN_ID}/artifacts/{artifact}"
            )
            responses.remove(responses.GET, artifact_url)
            responses.add(
                responses.GET,
                artifact_url,
                json=payload,
                match=[responses.matchers.query_param_matcher({"step": "2"})],
            )
    job_gets_before = sum(
        call.request.method == "GET" and call.request.url == job_url for call in responses.calls
    )
    job = define_asset_job("artifact_step", selection=AssetSelection.assets(*assets)).resolve(
        asset_graph=AssetGraph.from_assets(assets)
    )
    with instance_for_test() as instance:
        result = job.execute_in_process(instance=instance)
    assert result.success
    assert len(result.get_asset_materialization_events()) == 4
    job_gets_after = sum(
        call.request.method == "GET" and call.request.url == job_url for call in responses.calls
    )
    assert job_gets_after - job_gets_before == (job_state in {"null", "missing"})
